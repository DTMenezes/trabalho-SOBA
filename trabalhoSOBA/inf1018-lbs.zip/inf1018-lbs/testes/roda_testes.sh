#!/bin/sh
# Roda cada caso e compara com o valor esperado.
# Formato: arquivo argumento esperado

cd "$(dirname "$0")/.."
ok=0; falhas=0

while read arq arg esp; do
  [ -z "$arq" ] && continue
  case "$arq" in \#*) continue;; esac
  res=$(./teste "testes/$arq" "$arg")
  if [ "$res" = "$esp" ]; then
    echo "OK     $arq($arg) = $res"
    ok=$((ok+1))
  else
    echo "FALHOU $arq($arg) = $res (esperado $esp)"
    falhas=$((falhas+1))
  fi
done <<LISTA
constante.lbs           42   100
incremento.lbs          5    6
incremento.lbs          -1   0
identidade.lbs          -77  -77
fatorial.lbs            0    1
fatorial.lbs            1    1
fatorial.lbs            5    120
fatorial.lbs            10   3628800
soma_quadrados.lbs      0    0
soma_quadrados.lbs      3    14
soma_quadrados.lbs      10   385
negativos.lbs           4    -2
negativos.lbs           -5   25
so_constantes.lbs       0    -23
cinco_variaveis.lbs     3    29
zret_meio.lbs           5    500
zret_meio.lbs           6    60
zret_const_zero.lbs     8    8
zret_const_naozero.lbs  9    81
fibonacci.lbs           0    0
fibonacci.lbs           1    1
fibonacci.lbs           10   55
fibonacci.lbs           20   6765
cadeia_funcoes.lbs      4    24
recursao_contador.lbs   1000 1000
overflow.lbs            2    -2
sem_espacos.lbs         4    -10
LISTA

echo "----"
echo "$ok ok, $falhas falha(s)"
[ "$falhas" -eq 0 ]
