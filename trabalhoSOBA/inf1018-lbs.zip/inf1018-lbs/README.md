# INF1018 - Gerador de Código LBS (2026.2)

Micro-compilador da linguagem LBS para código de máquina x86-64.

## Estrutura

| Arquivo | O que é | Vai na entrega? |
|---|---|---|
| `gera_codigo.c` | O gerador de código | Sim |
| `relatorio.txt` | Relatório | Sim |
| `gera_codigo.h` | Header recriado do enunciado, trocar pelo original do site | Não |
| `main.c` | Programa de teste | Não |
| `testes/` | Funções LBS de teste + script com valores esperados | Não |
| `Makefile` | Atalhos de compilação | Não |
| `assembly/traducoes.s` | Moldes de assembly de cada comando LBS (origem dos opcodes) | Não |
| `assembly/traducoes_objdump.txt` | `objdump` do `.s` acima, bytes ao lado de cada instrução | Não |
| `assembly/gerado_*.txt` | Desmontagem do código que o gerador produz para fatorial, soma dos quadrados e Fibonacci | Não |

## Comandos

```bash
make                                  # compila ./teste
./teste testes/fatorial.lbs 5         # roda uma função LBS com argumento 5
make test                             # roda todos os casos e compara com o esperado
make disasm LBS=testes/fatorial.lbs   # mostra o assembly do código gerado
make clean
```

O aviso `requires executable stack` do linker é esperado: é justamente o `-Wa,--execstack` que permite executar o vetor `code`.

## Como o código gerado funciona

Registro de ativação de toda função:

| Posição | Conteúdo |
|---|---|
| `-4(%rbp)` a `-20(%rbp)` | `v0` a `v4` |
| `-24(%rbp)` | cópia de `p0` (chega em `%edi`) |

Reserva 32 bytes (24 arredondado pra múltiplo de 16, alinhamento exigido pela ABI antes de `call`).

| LBS | Tradução |
|---|---|
| `function` | `push %rbp`, `mov %rsp,%rbp`, `sub $32,%rsp`, `mov %edi,-24(%rbp)` |
| `vX = a op b` | `mov a,%eax`, `add/sub/imul b,%eax`, `mov %eax,vX` |
| `vX = call n a` | `mov a,%edi`, `call rel32`, `mov %eax,vX` |
| `ret a` | `mov a,%eax`, `leave`, `ret` |
| `zret a b` | `cmpl $0,a`, `jne +k`, bloco do `ret b` (com `a` constante, decide na compilação) |
| `end` | `leave`, `ret` de segurança |

O `call` resolve o endereço em uma passada só, porque uma função só chama a si mesma ou funções anteriores: o início de cada função fica guardado em `inicio_func[]` e o `rel32` é `destino - (posição depois do call)`.

## Antes de entregar

- Preencher nomes, matrículas e turma no topo do `gera_codigo.c` e no `relatorio.txt`
- Compilar com o `gera_codigo.h` original
- Conferir se o `relatorio.txt` reflete o estado final do código
