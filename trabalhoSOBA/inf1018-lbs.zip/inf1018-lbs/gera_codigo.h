/* Copia recriada a partir do enunciado so para compilar localmente.
   Substitua pelo gera_codigo.h original disponibilizado no site da disciplina. */
#include <stdio.h>

typedef int (*funcp) (int x);
void gera_codigo (FILE *f, unsigned char code[], funcp *entry);
