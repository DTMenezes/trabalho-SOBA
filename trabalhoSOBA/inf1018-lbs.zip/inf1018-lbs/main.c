/* Programa de teste do gerador. NAO faz parte da entrega.
 *
 * Uso: ./teste arquivo.lbs argumento [saida.bin]
 *
 * Se for passado o terceiro argumento, o codigo gerado e gravado
 * nesse arquivo para poder ser desmontado com:
 *   objdump -D -b binary -mi386:x86-64 saida.bin
 */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "gera_codigo.h"

#define TAM_CODE 1024

int main(int argc, char *argv[]) {
  FILE *fp;
  unsigned char code[TAM_CODE];
  funcp funcLBS;
  int res, arg;

  if (argc < 3) {
    fprintf(stderr, "uso: %s arquivo.lbs argumento [saida.bin]\n", argv[0]);
    return 1;
  }

  fp = fopen(argv[1], "r");
  if (fp == NULL) {
    perror(argv[1]);
    return 1;
  }
  arg = atoi(argv[2]);

  memset(code, 0, sizeof(code));
  gera_codigo(fp, code, &funcLBS);
  fclose(fp);

  if (funcLBS == NULL) {
    printf("Erro na geracao\n");
    return 1;
  }

  if (argc >= 4) {
    /* o codigo sempre termina em ret (0xc3), entao da pra cortar os zeros do fim */
    int tam = TAM_CODE;
    FILE *out = fopen(argv[3], "wb");
    while (tam > 0 && code[tam - 1] == 0) tam--;
    if (out != NULL) {
      fwrite(code, 1, tam, out);
      fclose(out);
    }
  }

  res = (*funcLBS)(arg);
  printf("%d\n", res);
  return 0;
}
